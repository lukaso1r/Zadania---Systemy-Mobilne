package com.example.quiz;

public class Pytania {
    public static String[][] pytaniaTab = {
            {"Kraków jest stolicą Polski?", "n"},
            {"Przez Warszawę płynie Odra?", "n"},
            {"Białystok powstał w 1440?", "t"},
            {"Polska graniczy z siedmioma państwami?", "t"},
            {"Najwyższa góra w Polsce to Rysy?", "t"}
    };


}
