//
//  SceneDelegate.h
//  ios6
//
//  Created by m1 on 14/11/2023.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

