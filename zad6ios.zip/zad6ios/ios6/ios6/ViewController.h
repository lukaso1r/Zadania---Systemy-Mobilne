//
//  ViewController.h
//  ios6
//
//  Created by m1 on 14/11/2023.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic, weak) IBOutlet UIButton *informationButton;
@property (nonatomic, weak) IBOutlet UIImageView *image;

@end

